from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
from sqlalchemy.orm import backref


class userParking(db.Model):
    __tablename__ = "userParking"
    upid = db.Column(db.Integer, primary_key=True)
    cid = db.Column(db.ForeignKey('user.id'))
    spot = db.Column(db.String(20))
    spotid = db.Column(db.Integer, db.ForeignKey("Parking.pid"))
    dateentry = db.Column(db.DateTime(timezone=True), default=func.now())
    dateexit = db.Column(db.DateTime(timezone=True))


class Parking(db.Model):
    __tablename__ = "Parking"
    spotname = db.Column(db.String(150))
    pid = db.Column(db.Integer, primary_key=True)
    status = db.Column(db.Integer)
    curcar = db.Column(db.String(11), db.ForeignKey("user.carnum"))
    userParking = db.relationship('userParking', backref='UParkingP')


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    carnum = db.Column(db.String(11), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    Parking = db.relationship('Parking', backref='parking_space')
    userParking = db.relationship('userParking', backref='UParkingU')
