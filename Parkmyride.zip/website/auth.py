from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import User, userParking, Parking
from werkzeug.security import generate_password_hash, check_password_hash
from . import db  # means from __init__.py import db
from flask_login import login_user, login_required, logout_user, current_user
from sqlalchemy import *
# from sqlalchemy.sql import func
import folium


auth = Blueprint('auth', __name__)


@auth.route('/homepage')
def homepage():
    return render_template("mainpage.html", user=current_user)


@auth.route('/map')
@login_required
def map():
    a0 = str(Parking.query.filter_by(spotname='APSIT').count())
    b0 = str(Parking.query.filter_by(spotname='APSIT', status=1).count())
    if int(b0) < 12:
        c0 = 'green'
    elif int(b0) < 23:
        c0 = 'orange'
    else:
        c0 = 'red'
    a1 = str(Parking.query.filter_by(spotname='GCORP').count())
    b1 = str(Parking.query.filter_by(spotname='GCORP', status=1).count())
    if int(b1) < 12:
        c1 = 'green'
    elif int(b1) < 23:
        c1 = 'orange'
    else:
        c1 = 'red'
    a2 = str(Parking.query.filter_by(spotname='HYPERCITY').count())
    b2 = str(Parking.query.filter_by(spotname='HYPERCITY', status=1).count())
    if int(b2) < 12:
        c2 = 'green'
    elif int(b2) < 23:
        c2 = 'orange'
    else:
        c2 = 'red'
    a3 = str(Parking.query.filter_by(spotname='ANANDNAGAR').count())
    b3 = str(Parking.query.filter_by(spotname='ANANDNAGAR', status=1).count())
    if int(b3) <= 12:
        c3 = 'green'
    elif int(b3) <= 23:
        c3 = 'orange'
    else:
        c3 = 'red'
    start_coords = (19.268022359115374, 72.96720694657441)
    f = folium.Figure(width=1000, height=500)
    folium_map = folium.Map(
        min_zoom=8,
        location=start_coords,
        zoom_start=17
    )
    folium.Marker([19.268022359115374, 72.96720694657441], radius=1, weight=1, border_width=10,
                  popup="<div style='width: 250px;'><h1>APSIT THANE</h1><p style='font-size: 2rem;'>Total Parking Spots: "+a0+"</p><p style='font-size: 2rem;'>In Use Parking Spots: "+b0+"</p><a type='button', href='/apsit' style='font-size: 2rem;'>View More</a></br></div>", tooltip='APSIT THANE', icon=folium.Icon(color=c0, icon_color="white", icon="home")).add_to(folium_map)
    folium.Marker([19.26618689920211, 72.96662999235318], radius=1, weight=1, border_width=10,
                  popup="<div style='width: 250px;'><h1>G CORP</h1><p style='font-size: 2rem;'>Total Parking Spots: "+a1+"</p><p style='font-size: 2rem;'>In Use Parking Spots: "+b1+"</p></p><a type='button', href='/gcorp' style='font-size: 2rem;'>View More</a></br></div>", tooltip='G-CORP THANE', icon=folium.Icon(color=c1, icon_color="white", icon="home")).add_to(folium_map)
    folium.Marker([19.26755417031544, 72.96566439718771], radius=1, weight=1, border_width=10,
                  popup="<div style='width: 250px;'><h1>HYPERCITY</h1><p style='font-size: 2rem;'>Total Parking Spots: "+a2+"</p><p style='font-size: 2rem;'>In Use Parking Spots: "+b2+"</p></p><a type='button', href='/hypercity' style='font-size: 2rem;'>View More</a></br></div>", tooltip='HYPERCITY MALL THANE', icon=folium.Icon(color=c2, icon_color="white", icon="home")).add_to(folium_map)
    folium.Marker([19.2673921239644, 72.96819640243137], radius=1, weight=1, border_width=10,
                  popup="<h1>ANANDNAGAR</h1><p style='font-size: 2rem;'>Total Parking Spots: "+a3+"</p><p style='font-size: 2rem;'>In Use Parking Spots: "+b3+"</p></p><a type='button', href='/anandnagar' style='font-size: 2rem;'>View More</a></br>", tooltip='ANANDNAGAR', icon=folium.Icon(color=c3, icon_color="white", icon="home")).add_to(folium_map)
    folium_map.save('website/templates/map.html')
    return render_template('map.html')


@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user:
            parking = Parking.query.filter_by(curcar=user.carnum).first()
            userparking = userParking.query.filter_by(
                cid=user.id, dateexit=None).first()
        if user:
            if check_password_hash(user.password, password):
                login_user(user, remember=True)
                if parking:
                    return redirect(url_for('auth.exitspot', var=userparking.spotid, parkid=userparking.upid,))
                else:
                    flash('Logged in successfully!', category='success')
                    return redirect(url_for('views.home', user=current_user))
            else:
                flash('Incorrect password, try again.', category='error')
        else:
            flash('Email does not exist.', category='error')

    return render_template("login.html", user=current_user)


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.homepage'))


@auth.route('/home')
@login_required
def home():
    return redirect(url_for('views.home'))


@auth.route('/about')
def about():
    return render_template("about.html", user=current_user)


@auth.route('/apsit')
@login_required
def apsit():
    userparking = userParking.query.filter_by(
        cid=current_user.id, dateexit=None).first()
    pcheck = Parking.query.filter_by(curcar=current_user.carnum).first()
    parking = Parking.query.filter_by(spotname='APSIT')
    if userparking:
        return render_template('apsit.html', user=current_user, parking=parking, pcheck=pcheck, var=userparking.spotid, parkid=userparking.upid,
                               userparking=userparking)
    else:
        return render_template('apsit.html', user=current_user, parking=parking, pcheck=pcheck, userparking=userparking)


@auth.route('/gcorp')
@login_required
def gcorp():
    userparking = userParking.query.filter_by(
        cid=current_user.id, dateexit=None).first()
    pcheck = Parking.query.filter_by(curcar=current_user.carnum).first()
    parking = Parking.query.filter_by(spotname='GCORP')
    if userparking:
        return render_template('gcorp.html', user=current_user, parking=parking, pcheck=pcheck, var=userparking.spotid, parkid=userparking.upid, userparking=userparking)
    else:
        return render_template('gcorp.html', user=current_user, parking=parking, pcheck=pcheck, userparking=userparking)


@auth.route('/hypercity')
@login_required
def hypercity():
    userparking = userParking.query.filter_by(
        cid=current_user.id, dateexit=None).first()
    pcheck = Parking.query.filter_by(curcar=current_user.carnum).first()
    parking = Parking.query.filter_by(spotname='HYPERCITY')
    if userparking:
        return render_template('hypercity.html', user=current_user, parking=parking, pcheck=pcheck, var=userparking.spotid, parkid=userparking.upid, userparking=userparking)
    else:
        return render_template('hypercity.html', user=current_user, parking=parking, pcheck=pcheck, userparking=userparking)


@auth.route('/anandnagar')
@login_required
def anandnagar():
    userparking = userParking.query.filter_by(
        cid=current_user.id, dateexit=None).first()
    pcheck = Parking.query.filter_by(curcar=current_user.carnum).first()
    parking = Parking.query.filter_by(spotname='ANANDNAGAR')
    if userparking:
        return render_template('anandnagar.html', user=current_user, parking=parking, pcheck=pcheck, var=userparking.spotid, parkid=userparking.upid, userparking=userparking)
    else:
        return render_template('anandnagar.html', user=current_user, parking=parking, pcheck=pcheck, userparking=userparking)


@auth.route('/spot', methods=['GET', 'POST'])
@login_required
def spot():
    my_var = request.args.get('my_var', None)
    parking = Parking.query.filter_by(pid=my_var).first()
    # spotid = request.args.get('spotid', None)
    if request.method == 'POST':
        spotid = request.form.get('spot-id')
        if int(spotid) == 1234:
            flash('spot taken', category='success')
            parking.status = 1
            parking.curcar = current_user.carnum
            cid = current_user.id
            spot = parking.spotname
            spotid = parking.pid
            dateentry = func.now()
            # datetime.datetime.now(tz=ZoneInfo(
            # 'Asia/Kolkata'))
            new_up = userParking(cid=cid, spotid=spotid,
                                 dateentry=dateentry, spot=spot)
            db.session.add(new_up)
            db.session.commit()
            try:
                parkid = userParking.query.filter_by(
                    cid=current_user.id).last()
            except:
                parkid = userParking.query.filter_by(
                    cid=current_user.id).first()
            return redirect(url_for('auth.home', var=my_var, parkid=parkid.upid))
        else:
            flash('Something Went Wrong', category='error')
    return render_template('spot.html', user=current_user, parking=parking, my_var=my_var)


@ auth.route('/exitspot', methods=['GET', 'POST'])
@ login_required
def exitspot():
    var = request.args.get('var', None)
    parkid = request.args.get('parkid', None)
    parking = Parking.query.filter_by(pid=var).first()
    UserParking = userParking.query.filter_by(upid=parkid).first()
    if request.method == 'POST':
        exitid = request.form.get('exit-id')
        try:
            if int(exitid) == 1234:
                flash('Exit Complete', category='success')
                parking.status = 0
                parking.curcar = None
                UserParking.dateexit = func.now()
                db.session.commit()
                return redirect(url_for('views.home'))
            else:
                flash('Wrong ID', category='error')
        except:
            flash('Something Went Wrong', category='error')
    return render_template('exitspot.html', user=current_user, parking=parking, var=var)


@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        carnum = request.form.get('carnum')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        elif len(carnum) != 10:
            flash('Enter correct car registered number')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        elif len(password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            new_user = User(email=email, first_name=first_name, carnum=carnum, password=generate_password_hash(
                password1, method='sha256'))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created!', category='success')
            return redirect(url_for('views.home'))

    return render_template("sign_up.html", user=current_user)
