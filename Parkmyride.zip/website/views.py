from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import User, userParking, Parking
from flask import Blueprint, render_template
from . import db
from sqlalchemy import *
from datetime import datetime, time

views = Blueprint('views', __name__)


@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    user = User.query.filter_by(email=current_user.email).first()
    data = userParking.query.filter_by(
        cid=user.id).order_by(desc(userParking.upid)).all()
    userparking = userParking.query.filter_by(
        cid=user.id, dateexit=None).first()
    parking = Parking.query.filter_by(curcar=user.carnum).first()
    '''a = []
    for d in data:
        x = dhms_from_seconds(date_diff_in_seconds(d.dateentry, d.dateexit))
        time = str(x[0])+" hours, "+str(x[1])+" minutes,"+str(x[2])+" seconds."
        a.append(time)'''
    if parking:
        return render_template("home.html", user=current_user, userparking=data, var=userparking.spotid, parkid=userparking.upid, p=parking)
    else:
        return render_template("home.html", user=current_user, userparking=data)


'''def date_diff_in_seconds(dt2, dt1):
    timedelta = dt2 - dt1
    return timedelta.days * 24 * 3600 + timedelta.seconds


def dhms_from_seconds(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    # days, hours = divmod(hours, 24)
    return (hours, minutes, seconds)'''
